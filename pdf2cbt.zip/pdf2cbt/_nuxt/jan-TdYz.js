import{a1 as t,a2 as e}from"./SvzITxsj.js";const r=()=>t(e.CurrentResultsID,()=>0);export{r as u};
