import"./SvzITxsj.js";const t=""+new URL("demo_test_data_pre_generated.Bq5xSNev.zip",import.meta.url).href;export{t as default};
