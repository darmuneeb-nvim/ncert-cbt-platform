import{i as l}from"./DFdfh4zV.js";import{a_ as s}from"./SvzITxsj.js";function u(r,i){return l(r)?!1:Array.isArray(r)?r.some(a=>s(a,i)):s(r,i)}export{u as i};
