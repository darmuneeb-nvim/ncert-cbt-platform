import{ap as s}from"./SvzITxsj.js";let i;const o=()=>{if(i===void 0){const e=s().public.isBuildForWebsite;i=e==="true"||e===!0}return i};export{o as u};
