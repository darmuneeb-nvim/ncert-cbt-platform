const e=t=>{const s=t.toLowerCase().split("x").map(Number).filter(r=>!Number.isNaN(r)),o={rows:4,cols:4};return s.length===1?(o.rows=s[0],o.cols=s[0]):(o.rows=s[0],o.cols=s[1]),o};export{e as u};
